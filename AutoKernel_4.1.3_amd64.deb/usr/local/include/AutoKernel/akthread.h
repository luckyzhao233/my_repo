/* akthread.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_THREAD_HH_INCLUDED__
#define __AK_THREAD_HH_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <stdint.h>
#include <pthread.h>

namespace AK {

class AK_PUBLIC TThread {
public:
  enum { kNone, kCreated, kRunning, kFinished, kCancelled, kExist, kError };
  typedef intptr_t (*const& PThreadRoutine)(void*);
  template <class T> struct PThreadClassRoutine
    { typedef intptr_t (T::*const& Type)(void*); };
public:
  inline TThread() : FThread(0) {}
  inline TThread(PThreadRoutine R, void* P, bool start = true)
    { Init(0, (void*)R, P, start); }
  template <class T> 
  inline TThread(const T* C, typename PThreadClassRoutine<T>::Type R,
                 void* P, bool start = true) { Init(C, &R, P, start); }
  ~TThread();
  inline int Create(PThreadRoutine R, void* P, bool start = true)
    { return Init(0, (void*)R, P, start); }
  template <class T>
  inline int Create(const T* C, typename PThreadClassRoutine<T>::Type R,
                    void* P, bool start = true)
    { return Init(C, &R, P, start); }
  int Status();
  int Start();
  int Start(void* param);
  int Stop();
  intptr_t Wait();
  intptr_t StopWait();
  inline static void SetStopPoint() { pthread_testcancel(); }
private:
  int Init(const void*, const void*, void*, bool);
private:
  intptr_t FThread;
};

} // namespace AK

#endif // __AK_THREAD_HH_INCLUDED__
