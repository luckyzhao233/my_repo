/* akcan.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_CAN_H_INCLUDED__
#define __AK_CAN_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <stdio.h>
#include <stdint.h>
#ifdef __linux__
  #include <linux/can.h>
#endif

namespace AK {

class AK_PUBLIC TCan {
public:
  TCan();
  explicit TCan(int channel, int bitrate = 0);
  bool Connect(int channel, int bitrate = 0);
  ~TCan();
  inline bool Connected() const { return FHandle != -1; }
  void Close();
  int Read(void*, uint32_t& id);
#ifdef __linux__
  int Read(struct can_frame&);
#endif
  int Write(const void* data, size_t bytes, uint32_t id);
  int Wait(int64_t nsec);
  int Block();
  int SetBlock(bool b);
private:
  int FHandle;
};

} // namespace AK

#endif // __AK_CAN_H_INCLUDED__
