/* ak.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_H_INCLUDED__
#define __AK_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <AutoKernel/akbase64.h>
#include <AutoKernel/akcan.h>
#include <AutoKernel/akdata.h>
#include <AutoKernel/aklog.h>
#include <AutoKernel/akmd5.h>
#include <AutoKernel/akmutex.h>
#include <AutoKernel/akqueue.h>
#include <AutoKernel/akserial.h>
#include <AutoKernel/akthread.h>
#include <AutoKernel/aktime.h>
#include <AutoKernel/aktopic.h>
#include <AutoKernel/aktransform.h>
#include <AutoKernel/akudp.h>

#endif // __AK_H_INCLUDED__
