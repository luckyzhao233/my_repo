/* aktime.h
 * 
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_TIME_H_INCLUDED__
#define __AK_TIME_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <stdint.h>
#include <time.h>
#include <errno.h>

namespace AK {

class AK_PUBLIC TTime {
public:
  inline TTime() {}
  inline ~TTime() {}
  inline static int64_t System() { return Monotonic() + FDiff; }
  inline static int64_t Monotonic()
    { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
      return t.tv_sec*1000000000ll + t.tv_nsec; }
  inline static int64_t System(int64_t t) { return t + FDiff; }
  inline static int64_t Monotonic(int64_t t) { return t - FDiff; }
  inline static int64_t Sleep(int64_t t)
    { if (t <= 0) return 0; struct timespec interval, rest;
      interval.tv_sec = t/1000000000; interval.tv_nsec = t%1000000000;
#ifdef __linux__
      if (EINTR == clock_nanosleep(CLOCK_MONOTONIC,0,&interval,&rest))
#else
      if (-1 == nanosleep(&interval, &rest) && EINTR == errno)
#endif
        return rest.tv_sec*1000000000ll+rest.tv_nsec; else return 0; }
  inline static int64_t SleepToSystem(int64_t t)
    { return SleepToMonotonic(t-FDiff) ? t : 0; }
  inline static int64_t SleepToMonotonic(int64_t t)
#ifdef __linux__
    { struct timespec deadline;
      deadline.tv_sec = t/1000000000; deadline.tv_nsec = t%1000000000;
      if (EINTR==clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&deadline,NULL))
#else
    { if (Sleep(t-Monotonic()))
#endif
        return t; else return 0; }
protected:
  static int64_t FDiff;
};

class AK_PUBLIC TRemoteTime {
public:
  TRemoteTime();
  inline ~TRemoteTime() {}
  int64_t Synchronize(int64_t local, int64_t remote);
  int64_t Synchronize(int64_t local, int64_t remote, int64_t remote_syn);
  inline int64_t _Synchronized() const { return FSynLocal; }
  inline int64_t Local(int64_t remote) const { return remote + FSyn; }
  inline int64_t System() const { return TTime::System() - FSyn; }
  inline int64_t Monotonic() const { return TTime::Monotonic() - FSyn; }
private:
  int64_t FSyn;
  int64_t FSynLocal;
  int64_t FSynRemote;
};

} // namespace AK

#endif // __AK_TIME_H_INCLUDED__
