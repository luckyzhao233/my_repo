/* akdata.h
 * 
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_DATA_H_INCLUDED__
#define __AK_DATA_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <stdint.h>

namespace AK {

struct AK_PUBLIC TData {
  inline TData() : Time(0) {}
  inline TData(int64_t t, int64_t s, const void* data)
    : Time(t), Size(s), Data((const uint8_t*)data) { }
  inline ~TData() {}
  uint64_t TopicId;
  int64_t Time;
  uint64_t Sequence;
  int64_t Size;
  const uint8_t* Data;
  const char* Topic;
};

} // namespace AK

#endif // __AK_DATA_H_INCLUDED__
