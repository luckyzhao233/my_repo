/* akqueue.h
 * 
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_QUEUE_H_INCLUDED__
#define __AK_QUEUE_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <stdint.h>
#include <time.h>
#include <errno.h>

namespace AK {

template <class T, size_t N>
class AK_PUBLIC TQueue {
public:
  inline TQueue() : FCount(0), FTop(0) {}
  inline size_t Size() const { return FCount; }
  inline size_t Push(const T& t)
    { FBuffer[FTop++] = t; if (FTop >= N) FTop = 0;
      if (FCount < N)  ++FCount; return FCount; }
  inline size_t Resize(size_t s)
    { if (s < FCount) FCount = s; return FCount; }
  inline size_t Pop(size_t i = 1)
    { if (i <= FCount) FCount -= i; return FCount; }
  inline T& Data(size_t i)
    { int n = FTop - FCount + i;
      while (n < 0) n += N; while (n >= N) n -= N;
      return FBuffer[n]; }
  inline T& operator[](size_t i) { return Data(i); }
private:
  T FBuffer[N];
  int FCount;
  int FTop;
};

} // namespace AK

#endif // __AK_QUEUE_H_INCLUDED__
