/* akbase64.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#ifndef __AK_BASE64_H_INCLUDED__
#define __AK_BASE64_H_INCLUDED__

#include <stdio.h>
#include <string.h>
#include <vector>

namespace AK {

class AK_PUBLIC TBase64 {
public:
  inline TBase64() {}
  inline explicit TBase64(const char* str, bool padding = false)
    { Base64(str, strlen(str), padding); }
  inline TBase64(const void* data, size_t length, bool padding = false)
    { Base64(data, length, padding); }
  inline ~TBase64() { }
  const char* Base64(const void* data, size_t length, bool padding = false);
  inline const char* Base64(const char* str, bool padding = false)
    { return Base64(str, strlen(str), padding); }
  inline const char* Base64() const { return FBase64.data(); }
  inline char Base64(int index) const { return FBase64[index]; }
  inline size_t Size() const { return FBase64.size()-1; }
private:
  std::vector<char> FBase64;
};

} // namespace AK

#endif // __AK_BASE64_H_INCLUDED__
