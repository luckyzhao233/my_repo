/* akserial.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_SERIAL_H_INCLUDED__
#define __AK_SERIAL_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

namespace AK {

class AK_PUBLIC TSerial {
public:
  inline TSerial() : FHandle(-1) {}
  inline explicit TSerial(const char* dev, int baudrate = 115200,
                          const char* params = NULL)
    : FHandle(-1) { Connect(dev, baudrate, params); }
  ~TSerial();
  bool Connect(const char* dev, int baudrate = 115200,
               const char* params = NULL);
  inline bool Connected() const { return FHandle != -1; }
  void Close();
  int Read(void* data, size_t bytes);
  int Write (const void* data, size_t bytes);
  int Wait(int64_t nsec);
  int ReadAll(void* data, size_t bytes);
  int Block();
  int SetBlock(bool b);
  int SetParam(int baudrate, const char* params = NULL);
private:
  int FHandle;
};

} // namespace AK

#endif // __AK_SERIAL_H_INCLUDED__
