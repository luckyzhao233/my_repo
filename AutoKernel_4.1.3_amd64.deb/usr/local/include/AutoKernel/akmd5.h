/* akmd5.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#ifndef __AK_MD5_H_INCLUDED__
#define __AK_MD5_H_INCLUDED__

#include <stdint.h>
#include <stdio.h>
#include <string.h>

namespace AK {

class AK_PUBLIC TMd5 {
public:
  TMd5();
  inline ~TMd5() { }
  inline explicit TMd5(const char* str) { Md5(str, strlen(str)); }
  inline TMd5(const void* data, size_t length) { Md5(data, length); }
  const uint8_t* Md5(const void* data, size_t length);
  inline const uint8_t* Md5(const char* str) { return Md5(str, strlen(str)); }
  inline const uint8_t* Md5() const { return FMd5; }
  inline uint8_t Md5(int index) const { return FMd5[index]; }
  inline int Size() const { return kMd5Bytes; }
private:
  enum { kMd5Bytes = 16 };
private:
  uint8_t FMd5[kMd5Bytes];
};

} // namespace AK

#endif // __AK_MD5_H_INCLUDED__
