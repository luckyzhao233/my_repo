/* aktopic.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_TOPIC_H_INCLUDED__
#define __AK_TOPIC_H_INCLUDED__

#include <AutoKernel/akdata.h>
#include <stdint.h>
#include <string.h>
#include <vector>
#include <string>

namespace AK {

class AK_PUBLIC TTopic {
public:
  typedef void (*const& PSubscribeRoutine)(const TData&);
  template <class T> struct PSubscribeClassRoutine 
    { typedef void (T::*const& Type)(const TData&); };
public:
  inline TTopic() : FId(0) {}
  explicit TTopic(const char* topic);
  TTopic(const char* topic, int64_t persistence);
  inline ~TTopic() {}
  bool SetTopic(const char* topic, int64_t persistence);
  inline bool SetTopic(const char* topic) { return SetTopic(topic, 0); }
  inline uint64_t Id() const { return FId; }
  const char* Topic();
  bool Publish(TData& data);
  inline bool Publish(int64_t time, int64_t size, const void* data)
    { TData d(time, size, data); return Publish(d); }
  inline bool Publish(int64_t time, const char* str)
    { return Publish(time, strlen(str)+1, str); }
  inline bool Subscribe(PSubscribeRoutine R)
    { return _Subscribe(FId, 0, (void*)R, false); }
  template <class T>
  inline bool Subscribe(const T* C, typename PSubscribeClassRoutine<T>::Type R)
    { return _Subscribe(FId, C, &R, false); }
public:
  static int64_t Init(const char * password, int64_t shared_memory_size);
  inline static int64_t Init(const char * password)
    { return Init(password, 0); }
  inline static int64_t Init() { return Init(NULL, 0); }
  static uint8_t* Request(int64_t size);
  static bool Release(uint8_t*);
  static int Update();
  static std::vector<const char*> List();
  inline static bool SubscribeAll(PSubscribeRoutine R)
    { return _Subscribe(0, 0, (void*)R, true); }
  template <class T>
  inline static bool SubscribeAll(const T* C,
                               typename PSubscribeClassRoutine<T>::Type R)
    { return _Subscribe(0, C, &R, true); }
private:
  static bool _Subscribe(uint64_t id, const void*, const void*, bool);
private:
  uint64_t FId;
};
  
} // namespace AK

#endif // __AK_TOPIC_H_INCLUDED__
