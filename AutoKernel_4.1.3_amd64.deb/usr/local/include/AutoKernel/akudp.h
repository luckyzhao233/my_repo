/* akudp.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_UDP_H_INCLUDED__
#define __AK_UDP_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

namespace AK {

class AK_PUBLIC TUdp {
public:
  inline TUdp() : FHandle(-1) {}
  inline explicit TUdp(const char* port) : FHandle(-1) { Bind(port); }
  inline explicit TUdp(const char* server, const char* port) : FHandle(-1)
    { Connect(server, port); }
  ~TUdp();
  bool Connect(const char* server, const char* port);
  bool Bind(const char* server, const char* port);
  inline bool Bind(const char* port) { return Bind(NULL, port); }
  inline bool Connected() const { return FHandle != -1; }
  void Close();
  int Read(void* data, size_t bytes);
  int Write (const void* data, size_t bytes);
  int Wait(int64_t nsec);
  int Block();
  int SetBlock(bool b);
private:
  int FHandle;
};

} // namespace AK

#endif // __AK_UDP_H_INCLUDED__
