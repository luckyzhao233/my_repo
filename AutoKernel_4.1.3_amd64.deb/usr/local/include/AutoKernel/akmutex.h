/* akmutex.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_MUTEX_H_INCLUDED__
#define __AK_MUTEX_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <AutoKernel/aklog.h>
#include <pthread.h>

namespace AK {

class AK_PUBLIC TMutex {
public:
  inline TMutex() { int e = pthread_mutex_init(&FMutex, NULL);
    if (e) TLog::Critical(e, EMutex); }
  inline ~TMutex() { int e = pthread_mutex_destroy(&FMutex);
    if (e) TLog::Error(e, EMutexFree); }
  inline explicit TMutex(bool InterProcess)
    { if (InterProcess) 
        { pthread_mutexattr_t attr;
          int e = pthread_mutexattr_init(&attr); 
          if (e) TLog::Critical(e, EMutexTrue);
          e = pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED); 
          if (e) TLog::Critical(e, EMutexTrue);
#ifndef __APPLE__
          e = pthread_mutexattr_setrobust(&attr, PTHREAD_MUTEX_ROBUST);
          if (e) TLog::Critical(e, EMutexTrue);
#endif
          e = pthread_mutex_init(&FMutex, &attr);
          if (e) TLog::Critical(e, EMutexTrue);
          e = pthread_mutexattr_destroy(&attr);
          if (e) TLog::Error(e, EMutexTrue); }
      else { int e = pthread_mutex_init(&FMutex, NULL);
             if (e) TLog::Critical(e, EMutex); } }
  inline static void Init(TMutex& mutex, bool inter_process = false)
    { if (inter_process) 
        { pthread_mutexattr_t attr;
          int e = pthread_mutexattr_init(&attr);
          if (e) TLog::Critical(e, EMutexTrue);
          e = pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
          if (e) TLog::Critical(e, EMutexTrue);
#ifndef __APPLE__
          e = pthread_mutexattr_setrobust(&attr, PTHREAD_MUTEX_ROBUST);
          if (e) TLog::Critical(e, EMutexTrue);
#endif
          e = pthread_mutex_init(&(mutex.FMutex), &attr);
          if (e) TLog::Critical(e, EMutexTrue);
          e = pthread_mutexattr_destroy(&attr);
          if (e) TLog::Error(e, EMutexTrue); }
      else { int e = pthread_mutex_init(&(mutex.FMutex), NULL);
             if (e) TLog::Critical(e, EMutex); } }
private:
  friend class TLock;
  friend class TLockTry;
  inline bool Lock() { int e = pthread_mutex_lock(&FMutex);
#ifndef __APPLE__
    if (e == EOWNERDEAD) { TLog::Error(e, ELockDead);
	                   pthread_mutex_consistent(&FMutex); return true; }
#endif
    if (e) TLog::Error(e, ELock); return !e; }
  inline bool LockTry() { int e = pthread_mutex_trylock(&FMutex);
#ifndef __APPLE__
    if (e == EOWNERDEAD) { TLog::Error(e, ELockTryDead);
	                   pthread_mutex_consistent(&FMutex); return true; }
#endif
    if (e != EBUSY) TLog::Error(e, ELockTry); return !e; }
  inline bool UnLock() { int e = pthread_mutex_unlock(&FMutex);
    if (e) TLog::Error(e, EUnlock); return !e; }
private:
  TMutex(const TMutex&);
  TMutex& operator=(const TMutex&);
private:
  static const char EMutex[];
  static const char EMutexTrue[];
  static const char EMutexFree[];
  static const char ELock[];
  static const char ELockDead[];
  static const char ELockTry[];
  static const char ELockTryDead[];
  static const char EUnlock[];
protected:
  pthread_mutex_t FMutex;
};

class TCondMutex : public TMutex {
public:
  inline TCondMutex() : TMutex() { int e = pthread_cond_init(&FCond, NULL);
    if (e) TLog::Critical(e, ECondMutex); }
  inline explicit TCondMutex(bool InterProcess) : TMutex(InterProcess)
    { if (InterProcess)
        { pthread_condattr_t attr;
          int e = pthread_condattr_init(&attr); 
          if (e) TLog::Critical(e, ECondMutexTrue);
          e = pthread_condattr_setpshared(&attr, PTHREAD_PROCESS_SHARED); 
          if (e) TLog::Critical(e, ECondMutexTrue);
          e = pthread_cond_init(&FCond, &attr);
          if (e) TLog::Critical(e, ECondMutexTrue);
          e = pthread_condattr_destroy(&attr);
          if (e) TLog::Error(e, ECondMutexTrue); }
      else { int e = pthread_cond_init(&FCond, NULL);
             if (e) TLog::Critical(e, ECondMutex); } }
  inline ~TCondMutex() { this->TMutex::~TMutex();
    int e = pthread_cond_destroy(&FCond);
    if (e) TLog::Error(e, ECondMutexFree); }
  inline bool Signal() { int e = pthread_cond_signal(&FCond);
    if (e) TLog::Error(e, ECondMutexSignal); return !e; }
  inline bool Broadcast() { int e = pthread_cond_signal(&FCond);
    if (e) TLog::Error(e, ECondMutexBroadcast); return !e; }
private:
  friend class TLock;
  friend class TLockTry;
  inline bool Wait() { int e = pthread_cond_wait(&FCond, &FMutex);
    if (e) TLog::Error(e, ECondMutexWait); return !e; }
private:
  TCondMutex(const TMutex&);
  TCondMutex& operator=(const TMutex&);
private:
  static const char ECondMutex[];
  static const char ECondMutexTrue[];
  static const char ECondMutexFree[];
  static const char ECondMutexSignal[];
  static const char ECondMutexBroadcast[];
  static const char ECondMutexWait[];
private:
  pthread_cond_t FCond;
};

class TLock {
public:
  inline explicit TLock(const TMutex& m)
    : FMutex(const_cast<TMutex*>(&m)), FWait(false)
    { if (!(FMutex->Lock())) FMutex = 0; }
  inline explicit TLock(const TCondMutex& m)
    : FCond(const_cast<TCondMutex*>(&m)),
      FWait(true) { if (!(FCond->Lock())) FCond = 0;}
  inline ~TLock()
    { if (FWait && FCond) FCond->UnLock(); else if (FMutex) FMutex->UnLock(); }
  inline bool Locked() const { return FMutex; }
  inline bool Wait() const { return FWait && FCond ? FCond->Wait() : false; }
private:
  TLock(const TLock&);
  TLock& operator=(const TLock&);
private:
  union { TMutex* FMutex; TCondMutex* FCond; };
  bool FWait;
};

class TLockTry {
public:
  inline TLockTry(const TMutex& m): FMutex(const_cast<TMutex*>(&m)),FWait(false)
    { if (!(FMutex->LockTry())) FMutex = 0; }
  inline TLockTry(const TCondMutex& m) : FCond(const_cast<TCondMutex*>(&m)),
    FWait(true) { if (!(FCond->LockTry())) FCond = 0;}
  inline ~TLockTry()
    { if (FWait && FCond) FCond->UnLock(); else if (FMutex) FMutex->UnLock(); }
  inline bool Locked() const { return FMutex; }
  inline bool Wait() const { return FWait && FCond ? FCond->Wait() : false; }
private:
  TLockTry(const TLockTry&);
  TLockTry& operator=(const TLockTry&);
private:
  union { TMutex* FMutex; TCondMutex* FCond; };
  bool FWait;
};

class TSharedMutex {
public:
  inline TSharedMutex() { int e = pthread_rwlock_init(&FMutex, NULL);
    if (e) TLog::Critical(e, ESharedMutex); }
  inline ~TSharedMutex() { int e = pthread_rwlock_destroy(&FMutex);
    if (e) TLog::Error(e, ESharedMutexFree); }
  inline explicit TSharedMutex(bool InterProcess)
    { if (InterProcess)
        { pthread_rwlockattr_t attr;
          int e = pthread_rwlockattr_init(&attr); 
          if (e) TLog::Critical(e, ESharedMutexTrue);
          e = pthread_rwlockattr_setpshared(&attr, PTHREAD_PROCESS_SHARED); 
          if (e) TLog::Critical(e, ESharedMutexTrue);
          e = pthread_rwlock_init(&FMutex, &attr);
          if (e) TLog::Critical(e, ESharedMutexTrue);
          e = pthread_rwlockattr_destroy(&attr);
          if (e) TLog::Error(e, ESharedMutexTrue); }
     else { int e = pthread_rwlock_init(&FMutex, NULL);
            if (e) TLog::Critical(e, ESharedMutex); } }
private:
  friend class TReadLock;
  friend class TReadLockTry;
  friend class TWriteLock;
  friend class TWriteLockTry;
  inline bool ReadLock() { int e = pthread_rwlock_rdlock(&FMutex);
    if (e) TLog::Error(e, EReadLock); return !e; }
  inline bool WriteLock() { int e = pthread_rwlock_wrlock(&FMutex);
    if (e) TLog::Error(e, EWriteLock); return !e; }
  inline bool ReadLockTry() { int e = pthread_rwlock_tryrdlock(&FMutex);
    if (e != EBUSY) TLog::Error(e, EReadLockTry); return !e; }
  inline bool WriteLockTry() { int e = pthread_rwlock_trywrlock(&FMutex);
    if (e != EBUSY) TLog::Error(e, EWriteLockTry); return !e; }
  inline bool ReadUnLock() { int e = pthread_rwlock_unlock(&FMutex);
    if (e) TLog::Error(e, EReadUnlock); return !e; }
  inline bool WriteUnLock() { int e = pthread_rwlock_unlock(&FMutex);
    if (e) TLog::Error(e, EWriteUnlock); return !e; }
private:
  TSharedMutex(const TSharedMutex&);
  TSharedMutex& operator=(const TSharedMutex&);
private:
  static const char ESharedMutex[];
  static const char ESharedMutexTrue[];
  static const char ESharedMutexFree[];
  static const char EReadLock[];
  static const char EReadLockTry[];
  static const char EWriteLock[];
  static const char EWriteLockTry[];
  static const char EReadUnlock[];
  static const char EWriteUnlock[];
private:
  pthread_rwlock_t FMutex;
};

class TReadLock {
public:
  inline explicit TReadLock(const TSharedMutex& m): FMutex(const_cast<TSharedMutex*>(&m))
    { if (!(FMutex->ReadLock())) FMutex = 0; }
  inline ~TReadLock() { if (FMutex) FMutex->ReadUnLock(); }
  inline bool Locked() const { return FMutex; }
private:
  TReadLock(const TReadLock&);
  TReadLock& operator=(const TReadLock&);
private:
  TSharedMutex* FMutex;
};

class TReadLockTry {
public:
  inline explicit TReadLockTry(const TSharedMutex& m)
   : FMutex(const_cast<TSharedMutex*>(&m))
    { if (!(FMutex->ReadLockTry())) FMutex = 0; }
  inline ~TReadLockTry() { if (FMutex) FMutex->ReadUnLock(); }
  inline bool Locked() const { return FMutex; }
private:
  TReadLockTry(const TReadLockTry&);
  TReadLockTry& operator=(const TReadLockTry&);
private:
  TSharedMutex* FMutex;
};

class TWriteLock {
public:
  inline explicit TWriteLock(const TSharedMutex& m)
    : FMutex(const_cast<TSharedMutex*>(&m))
    { if (!(FMutex->WriteLock())) FMutex = 0; }
  inline ~TWriteLock() { if (FMutex) FMutex->WriteUnLock(); }
  inline bool Locked() const { return FMutex; }
private:
  TWriteLock(const TWriteLock&);
  TWriteLock& operator=(const TWriteLock&);
private:
  TSharedMutex* FMutex;
};

class TWriteLockTry {
public:
  inline explicit TWriteLockTry(const TSharedMutex& m)
   : FMutex(const_cast<TSharedMutex*>(&m))
    { if (!(FMutex->WriteLockTry())) FMutex = 0; }
  inline ~TWriteLockTry() { if (FMutex) FMutex->WriteUnLock(); }
  inline bool Locked() const { return FMutex; }
private:
  TWriteLockTry(const TWriteLockTry&);
  TWriteLockTry& operator=(const TWriteLockTry&);
private:
  TSharedMutex* FMutex;
};

} // namespace AK

#endif //__AK_MUTEX_H_INCLUDED__
