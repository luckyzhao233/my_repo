/* aklog.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_LOG_H_INCLUDED__
#define __AK_LOG_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL  __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <syslog.h>
#include <stdarg.h>
#include <errno.h>
#include <stdlib.h>
#include <atomic>

namespace AK {

class AK_PUBLIC TLog {
public:
  enum { kPanic = LOG_EMERG,
         kAlert = LOG_ALERT,
         kCritical = LOG_CRIT,
         kError = LOG_ERR,
         kWarning = LOG_WARNING,
         kNotice = LOG_NOTICE,
         kInfo = LOG_INFO,
         kDebug = LOG_DEBUG };
  typedef void (*const& PExitCallback)(void);
  template <class T> struct PExitClassCallback
    { typedef void (T::*const& Type)(void); };
  static inline int LastError() { return errno; }
  static inline void ClearError() { errno = 0; }
  static inline void Critical(int error) { SetError(error); exit(error); }
  static inline void Critical(int error, const char* format, ...)
    { SetError(error); 
      va_list args; va_start(args, format);
      Log(kCritical, format, args); va_end(args); exit(error); }
  static inline void Critical(const char* format, ...)
    { va_list args; va_start(args, format);
      Log(kCritical, format, args); va_end(args); exit(-1); }
  static inline void Error(int error) { SetError(error); }
  static inline void Error(int error, const char* format, ...)
    { SetError(error); if (FLevel < kError) return; 
      va_list args; va_start(args, format);
      Log(kError, format, args); va_end(args); }
  static inline void Error(const char* format, ...)
    { if (FLevel < kError) return; 
      va_list args; va_start(args, format);
      Log(kError, format, args); va_end(args); }
  static inline void Warning(int error) { SetError(error); }
  static inline void Warning(int error, const char* format, ...)
    { SetError(error); if (FLevel < kWarning) return; 
      va_list args; va_start(args, format);
      Log(kWarning, format, args); va_end(args); }
  static inline void Warning(const char* format, ...)
    { if (FLevel < kWarning) return; 
      va_list args; va_start(args, format);
      Log(kWarning, format, args); va_end(args); }
  static inline void Notice(const char* format, ...)
    { if (FLevel < kNotice) return; 
      va_list args; va_start(args, format);
      Log(kNotice, format, args); va_end(args); }
  static inline void Info(const char* format, ...)
    { if (FLevel < kInfo) return; 
      va_list args; va_start(args, format);
      Log(kInfo, format, args); va_end(args); }
  static inline void Debug(const char* format, ...)
    { if (FLevel < kDebug) return; 
      va_list args; va_start(args, format);
      Log(kDebug, format, args); va_end(args); }
  static inline int Level() { return FLevel; }
  static inline int SetLevel(int level)
    { return FLevel = (level < kCritical ? kCritical :
                       level > kDebug ? kDebug : level); }
  static void StdErr(bool);
  inline static void SetExit(PExitCallback R) { _SetExit(0, (void*)R); }
  template <class T>
  inline static void SetExit(const T* C, typename PExitClassCallback<T>::Type R)
    { _SetEixt(C, &R); }
  inline static bool Running() { if (FRunning) return true; return _ToExit(); }
  inline static bool Exiting() { return !Running(); }
private:
  static inline void SetError(int err) { if (err) errno = err; }
  static inline void Log(int level, const char* msg, va_list args)
    { vsyslog(level, msg, args); }
  static void _SetExit(const void* C, const void* R);
  static bool _ToExit();
private:
  static int volatile FLevel;
protected:
  static bool volatile FRunning;
};

} // namespace AK

#endif // __AK_LOG_H_INCLUDED__
