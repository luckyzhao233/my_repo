/* aktransform.h
 *
 * 2017-03-08
 * Song Zhiwei <zhiwei.song@singpilot.com>
 * Copyright (c) 2017, SingPilot Pte. Ltd., www.singpilot.com
 * All rights reserved.
 */

#ifndef __AK_TRANSFORM_H_INCLUDED__
#define __AK_TRANSFORM_H_INCLUDED__

#ifndef AK_LOCAL
  #define AK_LOCAL __attribute__ ((visibility ("hidden")))
#endif
#ifndef AK_PUBLIC
  #define AK_PUBLIC __attribute__ ((visibility ("default")))
#endif

#include <math.h>
#include <cmath>

namespace AK {

#ifdef signbit
inline double Sign(double x) { return signbit(x)? -1 : 1; }
#else
inline double Sign(double x) { return std::signbit(x)? -1 : 1; }
#endif

class TLine;
class TPlane;

class T2DPosition {
public:
  inline T2DPosition() : FX(0), FY(0) {}
  inline T2DPosition(double x, double y) : FX(x), FY(y) {}
  inline void SetXY(double x, double y) { FX = x; FY = y; }
  inline void SetX(double x) { FX = x; }
  inline void SetY(double y) { FY = y; }
  inline double X() const { return FX; }
  inline double Y() const { return FY; }
  inline T2DPosition Translate(double x, double y) const
    { return T2DPosition(FX+x, FY+y); }
  inline T2DPosition Translate(const T2DPosition& p) const
    { return T2DPosition(FX+p.FX, FY+p.FY); }
  inline T2DPosition Inverse() const { return T2DPosition(-FX, -FY); }
  inline double Dot(const T2DPosition& p) const { return FX*p.FX+FY*p.FY; }
  inline double Dot(double x, double y) const { return FX*x + FY*y; }
  inline T2DPosition operator+(const T2DPosition& p) const{return Translate(p);}
  inline T2DPosition operator-() const { return Inverse(); }
  inline T2DPosition operator-(const T2DPosition& p) const { return *this+(-p);}
  inline double operator*(const T2DPosition& p) const { return Dot(p); }
  inline T2DPosition operator*(double f) const { return T2DPosition(FX*f,FY*f);}
  inline T2DPosition operator/(double f) const { return T2DPosition(FX/f,FY/f);}
  inline double Mod2() const { return FX*FX+FY*FY; }
  inline double Mod() const { return sqrt(Mod2()); }
  inline double Angle() const { return atan2(FY, FX); }
  inline double Distance(const T2DPosition& p) const
    { return Inverse().Translate(p).Mod(); }
  inline double Distance(double x, double y) const
    { return Inverse().Translate(x,y).Mod(); }
  inline double Distance2(const T2DPosition& p) const
    { return Inverse().Translate(p).Mod2(); }
  inline double Distance2(double x, double y) const
    { return Inverse().Translate(x,y).Mod2(); }
  inline bool Equal(const T2DPosition& p) const
    { return FX == p.FX && FY == p.FY; }
  inline bool NotEqual(const T2DPosition& p) const 
    { return FX != p.FX || FY != p.FY; }
  inline bool operator==(const T2DPosition& p) const { return Equal(p); }
  inline bool operator!=(const T2DPosition& p) const { return NotEqual(p); }
private:
  double FX, FY;
};

class T2DOrientation {
public:
  inline T2DOrientation() : FYaw(0) {}
  inline T2DOrientation(double yaw) : FYaw(yaw) {}
  inline void SetYaw(double yaw) { FYaw = yaw; }
  inline double Yaw() const { return Normalize(FYaw); }
  inline T2DOrientation Rotate(double a) const { return T2DOrientation(FYaw+a);}
  inline T2DOrientation Rotate(const T2DOrientation& o) const 
    { return T2DOrientation(FYaw+o.FYaw); }
  inline T2DOrientation Inverse() const { return T2DOrientation(-FYaw); }
  inline T2DOrientation operator+(const T2DOrientation& o) const 
    { return Rotate(o); }
  inline T2DOrientation operator+(double a) const { return Rotate(a); }
  inline T2DOrientation operator-() const { return Inverse(); }
  inline T2DOrientation operator-(double a) const { return *this+(-a); }
  inline T2DOrientation operator-(const T2DOrientation& o) const 
    { return *this+(-o); }
  inline bool Equal(const T2DOrientation& o) const { return FYaw == o.FYaw; }
  inline bool NotEqual(const T2DOrientation& o) const { return FYaw != o.FYaw; }
  inline bool operator==(const T2DOrientation& o) const { return Equal(o); }
  inline bool operator!=(const T2DOrientation& o) const { return NotEqual(o); }
private:
  inline double Normalize(double a) const
    { while (a > M_PI) a -= 2*M_PI; while (a <= -M_PI) a += 2*M_PI; return a; }
  double FYaw;
};

class TLine {
public:
  inline TLine() : FA(0), FB(1), FC(0) {}
  inline TLine(double a, double b, double c) : FA(a), FB(b), FC(c) {}
  inline TLine(double x0, double y0, double x1, double y1)
    : FA(y1-y0), FB(x0-x1), FC(y0*(x1-x0)-x0*(y1-y0)) {}
  inline TLine(const T2DPosition& p0, const T2DPosition& p1): FA(p1.Y()-p0.Y()),
      FB(p0.X()-p1.X()), FC(p0.Y()*(p1.X()-p0.X())-p0.X()*(p1.Y()-p0.Y())) {}
  inline TLine(const T2DPosition& p, double a)
    : FA(sin(a)), FB(-cos(a)), FC(p.Y()*cos(a)-p.X()*sin(a)) {}
  inline void SetABC(double a, double b, double c) { FA = a; FB = b; FC = c; }
  inline double A() const { return FA; }
  inline double B() const { return FB; }
  inline double C() const { return FC; }
  inline double Y(double x) const { return FB ? (-FA*x-FC)/FB : 0; }
  inline double X(double y) const { return FA ? (-FB*y-FC)/FA : 0; }
  T2DPosition Intersection(const TLine& l) const {
    return T2DPosition((FB*l.FC-FC*l.FB)/(FA*l.FB-FB*l.FA),
                       (FC*l.FA-FA*l.FC)/(FA*l.FB-FB*l.FA));
  }
  inline T2DPosition operator*(const TLine& l) const { return Intersection(l); }
  inline TLine NormalLine(double x, double y) const
    { double a = Angle(), c = cos(a), s = sin(a); return TLine(c,s,-x*c-y*s); }
  inline TLine NormalLine(const T2DPosition& p) const 
    { return NormalLine(p.X(), p.Y()); }
  inline TLine NormalLine() const { return NormalLine(0, 0); }
  inline TLine ParallelLine(const AK::T2DPosition& p)
    { return TLine(FA, FB, -FA*p.X()-FB*p.Y()); }
  inline TLine ParallelLine(double d) const 
    { return TLine(FA, FB, FC+d*sqrt(FA*FA+FB*FB)); }
  inline double Mod2() const { return FC*FC/(FA*FA+FB*FB); }
  inline double Mod() const { return sqrt(Mod2()); }
  inline double Angle() const { return atan2(Sign(FC)*FA, -Sign(FC)*FB); }
  inline double NormalAngle() const { return atan2(-Sign(FC)*FB,-Sign(FC)*FA); }
  inline double Distance(double x, double y) const
    { return fabs(FA*x+FB*y+FC)/sqrt(FA*FA+FB*FB); }
  inline double Distance(const T2DPosition& p) const
    { return fabs(FA*p.X()+FB*p.Y()+FC)/sqrt(FA*FA+FB*FB); }
private:
  double FA, FB, FC;
};

class T3DPose;

class T2DPose : public T2DPosition, public T2DOrientation {
public:
  inline T2DPose() : T2DPosition(), T2DOrientation() {}
  inline T2DPose(double x, double y) : T2DPosition(x,y), T2DOrientation() {}
  inline T2DPose(double yaw) : T2DPosition(), T2DOrientation(yaw) {}
  inline T2DPose(double x, double y, double yaw) : T2DPosition(x,y),
                                                   T2DOrientation(yaw) {}
  inline T2DPose(const T2DPosition& p) : T2DPosition(p), T2DOrientation() {}
  inline T2DPose(const T2DOrientation& o) : T2DPosition(), T2DOrientation(o) {}
  inline T2DPose(const T2DPosition& p, const T2DOrientation& o) :
           T2DPosition(p), T2DOrientation(o) {}
  inline T2DPose(const T3DPose&);
  inline void Set(double x, double y, double yaw) { SetXY(x,y); SetYaw(yaw); }
  inline void SetPosition(const T2DPosition& p) { SetXY(p.X(), p.Y()); }
  inline void SetOrientation(const T2DOrientation& o) { SetYaw(o.Yaw()); }
  T2DPose Translate(const T2DPosition& p) const;
  inline T2DPose Translate(double x, double y) const
    { return Translate(T2DPosition(x, y)); }
  inline T2DPose Rotate(const T2DOrientation& o) const
    { return T2DPose(*(T2DPosition*)this, ((T2DOrientation*)this)->Rotate(o)); }
  inline T2DPose Transform(const T2DPose& p) const
    { return Translate(p).Rotate(p); }
  inline T2DPose Inverse() const
    { return T2DPose(((T2DOrientation*)this)->Inverse()).
                     Translate(((T2DPosition*)this)->Inverse()); }
  inline T2DPose operator+(const T2DPose& p) const { return Transform(p); }
  inline T2DPose operator-() const { return Inverse(); }
  inline T2DPose operator-(const T2DPose& p) const { return *this+(-p); }
  inline TLine LineX() const {
    AK::T2DPose p = T2DPose(*(T2DOrientation*)this).Translate(0,1);
    return TLine(p.X(), p.Y(), -Dot(p));
  }
  inline TLine LineY() const {
    AK::T2DPose p = T2DPose(*(T2DOrientation*)this).Translate(1,0);
    return TLine(p.X(), p.Y(), -Dot(p));
  }
  TLine Transform(const TLine& l) const;
  inline bool Equal(const T2DPose& p) const
    { return T2DPosition::Equal(p) && T2DOrientation::Equal(p); }
  inline bool NotEqual(const T2DPose& p) const 
    { return T2DPosition::NotEqual(p) || T2DOrientation::NotEqual(p); }
  inline bool operator==(const T2DPose& p) const { return Equal(p); }
  inline bool operator!=(const T2DPose& p) const { return NotEqual(p); }
};

class TCircle {
public:
  inline TCircle() : FRadius(0) {}
  inline TCircle(const T2DPosition& o, double r) : FOrigin(o), FRadius(r) {}
  TCircle(const T2DPosition& p0, const T2DPosition& p1, const T2DPosition& p2);
  inline void SetOrigin(const T2DPosition& o) { FOrigin = o; }
  inline void SetRadius(double r) { FRadius = r; }
  inline double Radius() const { return FRadius; }
  inline T2DPosition Origin() const { return FOrigin; }
  T2DPosition Intersection(const TLine& l, const T2DPosition& n) const;
private:
  T2DPosition FOrigin;
  double FRadius;
};

class T3DOrientation;

class T3DPosition : public T2DPosition {
public:
  inline T3DPosition() : T2DPosition(), FZ(0) {}
  inline T3DPosition(double x, double y, double z) : T2DPosition(x,y), FZ(z) {}
  inline T3DPosition(const T2DPosition& p) : T2DPosition(p), FZ(0) {}
  inline T3DPosition(const T2DPosition& p, double z) : T2DPosition(p), FZ(0) {}
  inline void SetXYZ(double x, double y, double z) { SetXY(x,y); FZ = z; }
  inline void SetZ(double z) { FZ = z; }
  inline double Z() const { return FZ; }
  inline T3DPosition Translate(const T3DPosition& p) const
    { return T3DPosition(X()+p.X(), Y()+p.Y(), FZ+p.FZ); }
  inline T3DPosition Translate(double x, double y, double z) const
    { return T3DPosition(X()+x, Y()+y, Z()+z); }
  inline T3DPosition Translate(double x, double y) const 
    { return T3DPosition(X()+x, Y()+y, Z()); }
  inline T3DPosition Translate(const T2DPosition& p) const
    { return T3DPosition(X()+p.X(), Y()+p.Y(), FZ); }
  inline T3DPosition Translate(const T2DPosition& p, double z) const
    { return T3DPosition(X()+p.X(), Y()+p.Y(), FZ+z); }
  inline T3DPosition Inverse() const { return T3DPosition(-X(), -Y(), -FZ); }
  inline double Dot(const T3DPosition& p) const
    { return X()*p.X() + Y()*p.Y() + FZ*p.FZ; }
  inline double Dot(double x, double y, double z)const{return X()*x+Y()*y+FZ*z;}
  inline double Dot(const T2DPosition& p, double z) const
    { return X()*p.X() + Y()*p.Y() + FZ*z; }
  inline T3DPosition Cross(const T3DPosition& p) const
    { return T3DPosition(Y()*p.FZ-FZ*p.Y(), FZ*p.X()-X()*p.FZ,
                         X()*p.Y()-Y()*p.X()); }
  inline T3DPosition operator+(const T3DPosition& p) const{return Translate(p);}
  inline T3DPosition operator+(const T2DPosition& p) const{return Translate(p);}
  inline T3DPosition operator-() const { return Inverse(); }
  inline T3DPosition operator-(const T3DPosition& p) const { return *this+(-p);}
  inline T3DPosition operator-(const T2DPosition& p) const { return *this+(-p);}
  inline double operator*(const T3DPosition& p) const { return Dot(p); }
  inline double operator*(const T2DPosition& p) const { return Dot(p); }
  inline T3DPosition operator*(double f) const
    { return T3DPosition(X()*f,Y()*f,FZ*f); }
  inline T3DPosition operator^(const T3DPosition& p) const { return Cross(p); }
  inline double Mod2() const { return X()*X()+Y()*Y()+FZ*FZ; }
  inline double Mod() const { return sqrt(Mod2()); }
  inline double ModXY2() const { return X()*X()+Y()*Y(); }
  inline double ModXY() const { return sqrt(ModXY2()); }
  inline double ModYZ2() const { return Y()*Y()+FZ*FZ; }
  inline double ModYZ() const { return sqrt(ModYZ2()); }
  inline double ModZX2() const { return FZ*FZ+X()*X(); }
  inline double ModZX() const { return sqrt(ModZX()); }
  inline double AngleX() const { return atan2(Sign(Y())*ModYZ(), X()); }
  inline double AngleY() const { return atan2(Sign(Z())*ModZX(), Y()); }
  inline double AngleZ() const { return atan2(Sign(X())*ModXY(), FZ); }
  inline double AngleXY() const { return atan2(FZ, ModXY()); }
  inline double AngleYZ() const { return atan2(X(), ModYZ()); }
  inline double AngleZX() const { return atan2(Y(), ModZX()); }
  inline T3DOrientation Direction() const;
  inline double Distance(const AK::T3DPosition& p) const 
    { return Inverse().Translate(p).Mod(); }
  inline double Distance2(const AK::T3DPosition& p) const
    { return Inverse().Translate(p).Mod2(); }
  inline bool Equal(const T3DPosition& p) const
    { return T2DPosition::Equal(p) && FZ == p.FZ; }
  inline bool NotEqual(const T3DPosition& p) const
    { return T2DPosition::NotEqual(p) || FZ != p.FZ; }
  inline bool operator==(const T3DPosition& p) const { return Equal(p); }
  inline bool operator!=(const T3DPosition& p) const { return NotEqual(p); }
  inline bool Normalized() const { return Mod2() == 1.; }
  inline T3DPosition Normalize() const
    { double s = Mod2(); if (!s) return T3DPosition(1,0,0);
      if (s == 1.) return *this;
      s = sqrt(s); return T3DPosition(X()/s, Y()/s, FZ/s); }
private:
  double FZ;
};

class T3DOrientation {
public:
  inline T3DOrientation() : FQw(1), FQx(0), FQy(0), FQz(0) {}
  inline T3DOrientation(double qw, double qx, double qy, double qz)
    : FQw(qw), FQx(qx), FQy(qy), FQz(qz) {}
  inline T3DOrientation(double yaw, double pitch, double roll)
    { SetYPR(yaw, pitch, roll); }
  inline T3DOrientation(const T2DOrientation& o) { SetYPR(o.Yaw(),0,0); }
  inline T3DOrientation(const T2DOrientation& o, double p, double r)
    { SetYPR(o.Yaw(), p, r); }
  inline void SetQuaternion(double qw, double qx, double qy, double qz)
    { FQw = qw; FQx = qx; FQy = qy; FQz = qz; }
  void SetYPR(double yaw, double pitch, double roll);
  inline void SetYaw(double yaw) { return SetYPR(yaw, Pitch(), Roll()); }
  inline void SetPitch(double pitch) { return SetYPR(Yaw(), pitch, Roll()); }
  inline void SetRoll(double roll) { return SetYPR(Yaw(), Pitch(), roll); }
  inline double Qw() const { return FQw; }
  inline double Qx() const { return FQx; }
  inline double Qy() const { return FQy; }
  inline double Qz() const { return FQz; }
  double Yaw() const;
  double Pitch() const;
  double Roll() const;
  inline operator T2DOrientation() const { return T2DOrientation(Yaw()); }
  T3DOrientation Rotate(const T3DOrientation& q) const;
  inline T3DOrientation Rotate(double yaw, double pitch, double roll) const
    { return Rotate(T3DOrientation(yaw, pitch, roll)); }
  inline T3DOrientation Rotate(double qw, double qx, double qy, double qz) const
    { return Rotate(T3DOrientation(qw, qx, qy, qz)); }
  inline T3DOrientation Rotate(const T2DOrientation& o, double p, double r)
    const { return Rotate(T3DOrientation(o, p, r)); }
  inline T3DOrientation Rotate(const T2DOrientation& o) const
    { return Rotate(T3DOrientation(o)); }
  inline T3DOrientation Rotate(double yaw) const
    { return Rotate(T3DOrientation(T2DOrientation(yaw))); }
  inline T3DOrientation Inverse() const
    { return T3DOrientation(FQw, -FQx, -FQy, -FQz); }
  inline T3DOrientation operator+(const T3DOrientation& o) const
    { return Rotate(o); }
  inline T3DOrientation operator+(const T2DOrientation& o) const
    { return Rotate(o); }
  inline T3DOrientation operator+(double yaw) const { return Rotate(yaw); }
  inline T3DOrientation operator-() const { return Inverse(); }
  inline T3DOrientation operator-(const T3DOrientation& o) const
    { return *this+(-o); }
  inline T3DOrientation operator-(const T2DOrientation& o) const
    { return *this+(-o); }
  inline T3DOrientation operator-(double yaw) const { return *this+(-yaw); }
  inline bool Equal(const T3DOrientation& o) const
    { return FQw == o.FQw && FQx == o.FQx && FQy == o.FQy && FQz == o.FQz; }
  inline bool NotEqual(const T3DOrientation& o) const
    { return FQw != o.FQw || FQx != o.FQx || FQy != o.FQy || FQz != o.FQz; }
  inline bool operator==(const T3DOrientation& o) const { return Equal(o); }
  inline bool operator!=(const T3DOrientation& o) const { return NotEqual(o); }
private:
  double FQw, FQx, FQy, FQz;
};

class T3DLine {
public:
  inline T3DLine() : FDirection(1,0,0) {}
  inline T3DLine(const T3DPosition& o, const T3DPosition& d)
    : FOrigin(o), FDirection(d.Normalize()) {}
  inline T3DLine(double x, double y, double z, const T3DPosition& d)
    : FOrigin(x,y,z), FDirection(d.Normalize()) {}
  inline T3DPosition XY(double z) const
    { if (FDirection.Z()) { double dz = z - FOrigin.Z();
        return T3DPosition(FOrigin.X()+dz*FDirection.X()/FDirection.Z(),
                           FOrigin.Y()+dz*FDirection.Y()/FDirection.Z(), z); }
      else return T3DPosition(0,0,z?0:-1); }
private:
  T3DPosition FOrigin, FDirection;
};

class TPlane {
public:
  inline TPlane() : FNormal(0,0,1), FD(0) {}
  inline TPlane(const T3DPosition& p, double d) : FNormal(p), FD(d) {}
  inline TPlane(double a, double b, double c, double d) : FNormal(a,b,c),FD(d){}
  inline double A() const { return FNormal.X(); }
  inline double B() const { return FNormal.Y(); }
  inline double C() const { return FNormal.Z(); }
  inline double D() const { return FD; }
  inline void SetABCD(double a, double b, double c, double d)
    { FNormal.SetXYZ(a,b,c); FD = d; }
  inline double Z(double x, double y) const
    { return -(A()*x + B()*y + FD)/C(); }
  inline double Distance(const T3DPosition& p) const
    { return fabs(FNormal.Dot(p)+FD)/FNormal.Mod(); }
  inline double Angle(const TPlane& p) const
    { return acos(FNormal.Dot(p.FNormal)/(FNormal.Mod()*p.FNormal.Mod())); }
  inline double AngleXY() const { return Angle(TPlane(0,0,1,0)); }
  inline double AngleYZ() const { return Angle(TPlane(1,0,0,0)); }
  inline double AngleZX() const { return Angle(TPlane(0,1,0,0)); }
  inline TLine LineXY() const { return TLine(A(), B(), FD); }
  inline TLine LineYZ() const { return TLine(B(), C(), FD); }
  inline TLine LineZX() const { return TLine(C(), A(), FD); }
  inline bool Parallel(const TPlane& p) const
    { return B()*p.C() == C()*p.B() && C()*p.A() == A()*p.C() &&
             A()*p.B() == B()*p.A(); }
  inline bool Interceptable(const TPlane& p) const
    { return B()*p.C() != C()*p.B() || C()*p.A() != A()*p.C() ||
             A()*p.B() != B()*p.A(); }
  T3DLine Intersection(const TPlane&) const;
  inline T3DLine operator*(const TPlane& p) const { return Intersection(p); }
  inline bool Normalized() const { return FNormal.Normalized(); }
  inline TPlane Normalize() const 
    { double s = FNormal.Mod2(); if (!s) return TPlane(0,0,1,FD);
      if (s == 1.) return *this;
      s = sqrt(s); return TPlane(A()/s, B()/s, C()/s, FD/s); }
private:
  T3DPosition FNormal;
  double FD;
};

class T3DPose : public T3DPosition, public T3DOrientation {
public:
  inline T3DPose() : T3DPosition(), T3DOrientation() {}
  inline T3DPose(double x, double y, double z)
    : T3DPosition(x,y,z), T3DOrientation() {}
  inline T3DPose(double qw, double qx, double qy, double qz)
    : T3DPosition(), T3DOrientation(qw, qx, qy, qz) {}
  inline T3DPose(double x, double y, double z,
                 double qw, double qx, double qy, double qz)
    : T3DPosition(x, y, z), T3DOrientation(qw, qx, qy, qz) {}
  inline T3DPose(double x, double y, double z,
                 double yaw, double pitch, double roll)
    : T3DPosition(x, y, z), T3DOrientation(yaw, pitch, roll) {}
  inline T3DPose(const T3DPosition& p, const T3DOrientation q) 
    : T3DPosition(p), T3DOrientation(q) {}
  inline T3DPose(const T3DPosition& p) : T3DPosition(p), T3DOrientation() {}
  inline T3DPose(const T3DOrientation& q): T3DPosition(), T3DOrientation(q) {}
  inline T3DPose(double x, double y, double z, const T3DOrientation& q)
    : T3DPosition(x, y, z), T3DOrientation(q) {}
  inline T3DPose(const T3DPosition& p,
                 double qw, double qx, double qy, double qz)
    : T3DPosition(p), T3DOrientation(qw, qx, qy, qz) {}
  inline T3DPose(const T3DPosition& p, double yaw, double pitch, double roll)
    : T3DPosition(p), T3DOrientation(yaw, pitch, roll) {}
  inline T3DPose(const T2DPose& p) : T3DPosition(p), T3DOrientation(p) {}
  inline T3DPosition Position() const { return *this; }
  inline T3DOrientation Orientation() const { return *this; }
  T3DPose Translate(const T3DPosition& p) const;
  inline T3DPose Translate(double x, double y, double z) const
    { return Translate(T3DPosition(x,y,z)); }
  inline T3DPose Translate(const T2DPosition& p, double z) const
    { return Translate(T3DPosition(p, z)); }
  inline T3DPose Translate(const T2DPosition& p) const
    { return Translate(T3DPosition(p)); }
  inline T3DPose Translate(double x, double y) const
    { return Translate(T3DPosition(T2DPosition(x,y))); }
  inline T3DPose Rotate(const T3DOrientation& q) const
    { return T3DPose(Position(), Orientation().Rotate(q)); }
  inline T3DPose Rotate(double qw, double qx, double qy, double qz) const
    { return Rotate(T3DOrientation(qw, qx, qy, qz)); }
  inline T3DPose Rotate(double yaw, double pitch, double roll) const
    { return Rotate(T3DOrientation(yaw, pitch, roll)); }
  inline T3DPose Rotate(const T2DOrientation& o, double p, double r) const
    { return Rotate(T3DOrientation(o, p, r)); }
  inline T3DPose Rotate(const T2DOrientation& o) const
    { return Rotate(T3DOrientation(o)); }
  inline T3DPose Rotate(double yaw) const
    { return Rotate(T3DOrientation(T2DOrientation(yaw))); }
  inline T3DPose Transform(const T3DPose& p) const 
    { return Translate(p).Rotate(p); }
  inline T3DPose Transform(const T2DPose& p) const
    { return Translate(p).Rotate(p); }
  inline T3DPose Transform(const T3DPosition& p) const { return Translate(p); }
  inline T3DPose Transform(const T2DPosition& p) const { return Translate(p); }
  inline T3DPose Transform(const T3DOrientation& q) const { return Rotate(q); }
  inline T3DPose Transform(const T2DOrientation& q) const { return Rotate(q); }
  inline T3DPose Inverse() const 
    { return T3DPose(Orientation().Inverse()).Translate(Position().Inverse()); }
  inline T3DPose operator+(const T3DPose& p) const { return Transform(p); }
  inline T3DPose operator+(const T2DPose& p) const { return Transform(p); }
  inline T3DPose operator+(const T3DPosition& p) const { return Transform(p); }
  inline T3DPose operator+(const T2DPosition& p) const { return Transform(p); }
  inline T3DPose operator+(const T3DOrientation& o) const {return Transform(o);}
  inline T3DPose operator+(const T2DOrientation& o) const {return Transform(o);}
  inline T3DPose operator-() const { return Inverse(); }
  inline T3DPose operator-(const T3DPose& p) const { return *this+(-p); }
  inline T3DPose operator-(const T2DPose& p) const { return *this+(-p); }
  inline T3DPose operator-(const T3DPosition& p) const { return *this+(-p); }
  inline T3DPose operator-(const T2DPosition& p) const { return *this+(-p); }
  inline T3DPose operator-(const T3DOrientation& o) const { return *this+(-o); }
  inline T3DPose operator-(const T2DOrientation& o) const { return *this+(-o); }
  inline bool Equal(const T3DPose& p) const
    { return T3DPosition::Equal(p) && T3DOrientation::Equal(p); }
  inline bool NotEqual(const T3DPose& p) const
    { return T3DPosition::NotEqual(p) || T3DOrientation::NotEqual(p); }
  inline bool operator==(const T3DPose& p) const { return Equal(p); }
  inline bool operator!=(const T3DPose& p) const { return NotEqual(p); }
  TPlane PlaneXY() const;
  TPlane PlaneYZ() const;
  TPlane PlaneZX() const;
};
  
inline T2DPose::T2DPose(const T3DPose& p)
  : T2DPosition(p), T2DOrientation(p.Yaw()) {}
inline T3DOrientation T3DPosition::Direction() const
  { return T3DOrientation(Angle(), -AngleXY(), 0); }

} // namespace AK

#endif // __AK_TRANSFORM_H_INCLUDED__
